def get_text():
    print("Hello from my first python package")


if __name__ == "__main__":
  get_text()